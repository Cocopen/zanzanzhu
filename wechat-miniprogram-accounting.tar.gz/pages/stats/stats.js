// pages/stats/stats.js
import * as echarts from '../../utils/ec-canvas/echarts'

let pieChart = null
let lineChart = null

function initPieChart(canvas, width, height, dpr) {
  pieChart = echarts.init(canvas, null, {
    width: width,
    height: height,
    devicePixelRatio: dpr
  })
  canvas.setChart(pieChart)
  return pieChart
}

function initLineChart(canvas, width, height, dpr) {
  lineChart = echarts.init(canvas, null, {
    width: width,
    height: height,
    devicePixelRatio: dpr
  })
  canvas.setChart(lineChart)
  return lineChart
}

Page({
  /**
   * 页面的初始数据
   */
  data: {
    periodType: 'month', // month 或 year
    currentYear: new Date().getFullYear(),
    currentMonth: new Date().getMonth() + 1,
    pieEc: {
      onInit: initPieChart
    },
    lineEc: {
      onInit: initLineChart
    },
    pieData: [],
    dataCards: [],
    suggestions: []
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.loadPieChartData()
    this.loadLineChartData()
    this.loadDataCards()
    this.loadSuggestions()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {
    // 渲染图表
    this.renderPieChart()
    this.renderLineChart()
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    if (pieChart) {
      this.loadPieChartData()
      this.renderPieChart()
    }
    if (lineChart) {
      this.loadLineChartData()
      this.renderLineChart()
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {
    if (pieChart) {
      pieChart.dispose()
      pieChart = null
    }
    if (lineChart) {
      lineChart.dispose()
      lineChart = null
    }
  },

  /**
   * 加载饼图数据
   */
  loadPieChartData() {
    const that = this
    const db = wx.cloud.database()
    const _ = db.command
    
    let startDate, endDate
    if (this.data.periodType === 'month') {
      startDate = new Date(this.data.currentYear, this.data.currentMonth - 1, 1)
      endDate = new Date(this.data.currentYear, this.data.currentMonth, 0, 23, 59, 59)
    } else {
      startDate = new Date(this.data.currentYear, 0, 1)
      endDate = new Date(this.data.currentYear, 11, 31, 23, 59, 59)
    }
    
    db.collection('bills').where({
      type: 'expense',
      date: _.gte(startDate).and(_.lte(endDate))
    }).get({
      success: res => {
        const categoryMap = {}
        res.data.forEach(bill => {
          const categoryName = bill.category.name
          if (!categoryMap[categoryName]) {
            categoryMap[categoryName] = {
              name: categoryName,
              value: 0,
              color: bill.category.color
            }
          }
          categoryMap[categoryName].value += parseFloat(bill.amount)
        })
        
        // 转为数组
        const data = Object.values(categoryMap)
        
        // 计算百分比
        const total = data.reduce((sum, item) => sum + item.value, 0)
        data.forEach(item => {
          item.percent = total > 0 ? ((item.value / total) * 100).toFixed(1) : 0
          item.value = item.value.toFixed(2)
        })
        
        // 按金额排序
        data.sort((a, b) => parseFloat(b.value) - parseFloat(a.value))
        
        that.setData({
          pieData: data
        })
      }
    })
  },

  /**
   * 渲染饼图
   */
  renderPieChart() {
    if (!pieChart) return
    
    const option = {
      tooltip: {
        trigger: 'item',
        formatter: '{b}: {c}元 ({d}%)'
      },
      legend: {
        show: false
      },
      series: [{
        name: '支出',
        type: 'pie',
        radius: ['40%', '70%'],
        center: ['50%', '50%'],
        avoidLabelOverlap: true,
        itemStyle: {
          borderRadius: 10,
          borderColor: '#fff',
          borderWidth: 2
        },
        label: {
          show: false
        },
        emphasis: {
          label: {
            show: true,
            fontSize: 20,
            fontWeight: 'bold'
          }
        },
        data: this.data.pieData.map(item => ({
          name: item.name,
          value: item.value,
          itemStyle: {
            color: item.color
          }
        }))
      }]
    }
    
    pieChart.setOption(option)
  },

  /**
   * 加载折线图数据
   */
  loadLineChartData() {
    const that = this
    const db = wx.cloud.database()
    const _ = db.command
    
    const months = []
    const incomeData = []
    const expenseData = []
    
    // 获取最近12个月的数据
    for (let i = 11; i >= 0; i--) {
      const date = new Date()
      date.setMonth(date.getMonth() - i)
      const year = date.getFullYear()
      const month = date.getMonth() + 1
      
      months.push(`${month}月`)
      
      const startDate = new Date(year, month - 1, 1)
      const endDate = new Date(year, month, 0, 23, 59, 59)
      
      // 查询该月收入和支出
      db.collection('bills').where({
        type: 'income',
        date: _.gte(startDate).and(_.lte(endDate))
      }).get({
        success: res => {
          let totalIncome = 0
          res.data.forEach(bill => {
            totalIncome += parseFloat(bill.amount)
          })
          incomeData.push(totalIncome.toFixed(2))
        }
      })
      
      db.collection('bills').where({
        type: 'expense',
        date: _.gte(startDate).and(_.lte(endDate))
      }).get({
        success: res => {
          let totalExpense = 0
          res.data.forEach(bill => {
            totalExpense += parseFloat(bill.amount)
          })
          expenseData.push(totalExpense.toFixed(2))
        }
      })
    }
    
    this.lineChartData = { months, incomeData, expenseData }
  },

  /**
   * 渲染折线图
   */
  renderLineChart() {
    if (!lineChart || !this.lineChartData) return
    
    const { months, incomeData, expenseData } = this.lineChartData
    
    const option = {
      tooltip: {
        trigger: 'axis'
      },
      legend: {
        data: ['收入', '支出'],
        top: 0
      },
      grid: {
        left: '10%',
        right: '5%',
        bottom: '10%',
        top: '15%'
      },
      xAxis: {
        type: 'category',
        boundaryGap: false,
        data: months,
        axisLine: {
          lineStyle: {
            color: '#d2d2d7'
          }
        }
      },
      yAxis: {
        type: 'value',
        axisLine: {
          lineStyle: {
            color: '#d2d2d7'
          }
        }
      },
      series: [{
        name: '收入',
        type: 'line',
        smooth: true,
        data: incomeData,
        itemStyle: {
          color: '#34c759'
        },
        areaStyle: {
          color: {
            type: 'linear',
            x: 0,
            y: 0,
            x2: 0,
            y2: 1,
            colorStops: [{
              offset: 0,
              color: 'rgba(52, 199, 89, 0.3)'
            }, {
              offset: 1,
              color: 'rgba(52, 199, 89, 0)'
            }]
          }
        }
      }, {
        name: '支出',
        type: 'line',
        smooth: true,
        data: expenseData,
        itemStyle: {
          color: '#ff3b30'
        },
        areaStyle: {
          color: {
            type: 'linear',
            x: 0,
            y: 0,
            x2: 0,
            y2: 1,
            colorStops: [{
              offset: 0,
              color: 'rgba(255, 59, 48, 0.3)'
            }, {
              offset: 1,
              color: 'rgba(255, 59, 48, 0)'
            }]
          }
        }
      }]
    }
    
    lineChart.setOption(option)
  },

  /**
   * 加载数据卡片
   */
  loadDataCards() {
    const that = this
    const db = wx.cloud.database()
    const _ = db.command
    
    let startDate, endDate
    if (this.data.periodType === 'month') {
      startDate = new Date(this.data.currentYear, this.data.currentMonth - 1, 1)
      endDate = new Date(this.data.currentYear, this.data.currentMonth, 0, 23, 59, 59)
    } else {
      startDate = new Date(this.data.currentYear, 0, 1)
      endDate = new Date(this.data.currentYear, 11, 31, 23, 59, 59)
    }
    
    // 查询总收入
    db.collection('bills').where({
      type: 'income',
      date: _.gte(startDate).and(_.lte(endDate))
    }).get({
      success: res => {
        let totalIncome = 0
        res.data.forEach(bill => {
          totalIncome += parseFloat(bill.amount)
        })
        
        // 查询总支出
        db.collection('bills').where({
          type: 'expense',
          date: _.gte(startDate).and(_.lte(endDate))
        }).get({
          success: res2 => {
            let totalExpense = 0
            res2.data.forEach(bill => {
              totalExpense += parseFloat(bill.amount)
            })
            
            that.setData({
              dataCards: [
                {
                  title: '总收入',
                  value: `¥${totalIncome.toFixed(2)}`,
                  icon: '↓',
                  color: '#34c759',
                  textClass: 'text-green'
                },
                {
                  title: '总支出',
                  value: `¥${totalExpense.toFixed(2)}`,
                  icon: '↑',
                  color: '#ff3b30',
                  textClass: 'text-red'
                },
                {
                  title: '总笔数',
                  value: `${res.data.length + res2.data.length}`,
                  icon: '📊',
                  color: '#0071e3',
                  textClass: 'text-blue'
                },
                {
                  title: '日均支出',
                  value: `¥${(totalExpense / 30).toFixed(2)}`,
                  icon: '💰',
                  color: '#ff9500',
                  textClass: ''
                }
              ]
            })
          }
        })
      }
    })
  },

  /**
   * 加载消费建议
   */
  loadSuggestions() {
    // 根据支出排行生成建议
    const suggestions = []
    
    if (this.data.pieData.length > 0) {
      const maxExpenseCategory = this.data.pieData[0]
      if (parseFloat(maxExpenseCategory.percent) > 40) {
        suggestions.push({
          icon: '⚠️',
          title: '注意控制支出',
          content: `${maxExpenseCategory.name}支出占比过高(${maxExpenseCategory.percent}%)，建议适当控制`
        })
      }
    }
    
    suggestions.push({
      icon: '💡',
      title: '合理规划预算',
      content: '建议每月设定预算目标，并定期查看支出趋势'
    })
    
    suggestions.push({
      icon: '📈',
      title: '增加储蓄',
      content: '尝试每月固定储蓄收入的20%-30%，培养储蓄习惯'
    })
    
    this.setData({
      suggestions
    })
  },

  /**
   * 切换期间类型
   */
  switchPeriod(e) {
    const type = e.currentTarget.dataset.type
    this.setData({
      periodType: type
    })
    this.loadPieChartData()
    this.loadLineChartData()
    this.loadDataCards()
    this.loadSuggestions()
    
    if (pieChart) {
      this.renderPieChart()
    }
    if (lineChart) {
      this.renderLineChart()
    }
  },

  /**
   * 上个月
   */
  prevMonth() {
    let { currentYear, currentMonth } = this.data
    
    if (currentMonth === 1) {
      currentMonth = 12
      currentYear -= 1
    } else {
      currentMonth -= 1
    }
    
    this.setData({
      currentYear,
      currentMonth
    })
    this.loadPieChartData()
    this.loadDataCards()
    this.loadSuggestions()
    
    if (pieChart) {
      this.renderPieChart()
    }
  },

  /**
   * 下个月
   */
  nextMonth() {
    let { currentYear, currentMonth } = this.data
    
    if (currentMonth === 12) {
      currentMonth = 1
      currentYear += 1
    } else {
      currentMonth += 1
    }
    
    this.setData({
      currentYear,
      currentMonth
    })
    this.loadPieChartData()
    this.loadDataCards()
    this.loadSuggestions()
    
    if (pieChart) {
      this.renderPieChart()
    }
  },

  /**
   * 上一年
   */
  prevYear() {
    this.setData({
      currentYear: this.data.currentYear - 1
    })
    this.loadPieChartData()
    this.loadDataCards()
    this.loadSuggestions()
    
    if (pieChart) {
      this.renderPieChart()
    }
  },

  /**
   * 下一年
   */
  nextYear() {
    this.setData({
      currentYear: this.data.currentYear + 1
    })
    this.loadPieChartData()
    this.loadDataCards()
    this.loadSuggestions()
    
    if (pieChart) {
      this.renderPieChart()
    }
  }
})
