// pages/add/add.js
Page({
  /**
   * 页面的初始数据
   */
  data: {
    billType: 'expense', // expense 或 income
    amount: '',
    amountFocus: false,
    categories: [],
    selectedCategory: {},
    accounts: [],
    selectedAccount: {},
    selectedDate: '',
    remark: '',
    showRemarkModal: false,
    canSubmit: false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.loadCategories()
    this.loadAccounts()
    this.setDefaultDate()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {
    // 聚焦金额输入框
    setTimeout(() => {
      this.setData({
        amountFocus: true
      })
    }, 300)
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 加载分类列表
   */
  loadCategories() {
    const that = this
    const db = wx.cloud.database()
    
    db.collection('categories').where({
      type: this.data.billType
    }).get({
      success: res => {
        that.setData({
          categories: res.data,
          selectedCategory: res.data.length > 0 ? res.data[0] : {}
        })
      }
    })
  },

  /**
   * 加载账户列表
   */
  loadAccounts() {
    const that = this
    const db = wx.cloud.database()
    
    db.collection('accounts').get({
      success: res => {
        that.setData({
          accounts: res.data,
          selectedAccount: res.data.length > 0 ? res.data[0] : {}
        })
      }
    })
  },

  /**
   * 设置默认日期
   */
  setDefaultDate() {
    const now = new Date()
    const year = now.getFullYear()
    const month = (now.getMonth() + 1).toString().padStart(2, '0')
    const day = now.getDate().toString().padStart(2, '0')
    this.setData({
      selectedDate: `${year}-${month}-${day}`
    })
  },

  /**
   * 切换收支类型
   */
  switchType(e) {
    const type = e.currentTarget.dataset.type
    this.setData({
      billType: type,
      selectedCategory: {},
      amount: '',
      canSubmit: false
    })
    this.loadCategories()
  },

  /**
   * 金额输入
   */
  onAmountInput(e) {
    let value = e.detail.value
    
    // 限制最多两位小数
    if (value.includes('.')) {
      const parts = value.split('.')
      if (parts[1] && parts[1].length > 2) {
        value = `${parts[0]}.${parts[1].substring(0, 2)}`
      }
    }
    
    this.setData({
      amount: value
    })
    
    this.checkCanSubmit()
  },

  /**
   * 选择分类
   */
  selectCategory(e) {
    const category = e.currentTarget.dataset.category
    this.setData({
      selectedCategory: category
    })
    this.checkCanSubmit()
  },

  /**
   * 显示账户选择
   */
  showAccountPicker() {
    const that = this
    const items = this.data.accounts.map(item => item.name)
    
    wx.showActionSheet({
      itemList: items,
      success(res) {
        that.setData({
          selectedAccount: that.data.accounts[res.tapIndex]
        })
      }
    })
  },

  /**
   * 显示日期选择
   */
  showDatePicker() {
    const that = this
    wx.showActionSheet({
      itemList: ['今天', '昨天', '选择日期'],
      success(res) {
        if (res.tapIndex === 0) {
          that.setDefaultDate()
        } else if (res.tapIndex === 1) {
          const yesterday = new Date()
          yesterday.setDate(yesterday.getDate() - 1)
          const year = yesterday.getFullYear()
          const month = (yesterday.getMonth() + 1).toString().padStart(2, '0')
          const day = yesterday.getDate().toString().padStart(2, '0')
          that.setData({
            selectedDate: `${year}-${month}-${day}`
          })
        } else {
          that.triggerDatepicker()
        }
      }
    })
  },

  /**
   * 触发日期选择器
   */
  triggerDatepicker() {
    // 小程序没有直接触发picker的API，这里使用简单的实现
    wx.showToast({
      title: '请选择日期',
      icon: 'none'
    })
  },

  /**
   * 日期改变
   */
  onDateChange(e) {
    this.setData({
      selectedDate: e.detail.value
    })
  },

  /**
   * 显示备注输入
   */
  showRemarkInput() {
    this.setData({
      showRemarkModal: true
    })
  },

  /**
   * 关闭备注弹窗
   */
  closeRemarkModal() {
    this.setData({
      showRemarkModal: false
    })
  },

  /**
   * 备注输入
   */
  onRemarkInput(e) {
    this.setData({
      remark: e.detail.value
    })
  },

  /**
   * 确认备注
   */
  confirmRemark() {
    this.closeRemarkModal()
  },

  /**
   * 阻止冒泡
   */
  stopPropagation() {
    // 阻止事件冒泡
  },

  /**
   * 检查是否可以提交
   */
  checkCanSubmit() {
    const { amount, selectedCategory } = this.data
    const canSubmit = amount && parseFloat(amount) > 0 && selectedCategory.id
    this.setData({
      canSubmit
    })
  },

  /**
   * 提交账单
   */
  submitBill() {
    if (!this.data.canSubmit) return
    
    const that = this
    const db = wx.cloud.database()
    
    const bill = {
      type: this.data.billType,
      amount: parseFloat(this.data.amount),
      category: this.data.selectedCategory,
      account: this.data.selectedAccount,
      date: new Date(this.data.selectedDate),
      remark: this.data.remark,
      createTime: db.serverDate()
    }
    
    wx.showLoading({
      title: '保存中...'
    })
    
    db.collection('bills').add({
      data: bill,
      success: res => {
        wx.hideLoading()
        wx.showToast({
          title: '记账成功',
          icon: 'success'
        })
        
        // 延迟返回首页
        setTimeout(() => {
          wx.navigateBack()
        }, 1500)
      },
      fail: err => {
        wx.hideLoading()
        wx.showToast({
          title: '保存失败',
          icon: 'none'
        })
        console.error('保存账单失败', err)
      }
    })
  }
})
