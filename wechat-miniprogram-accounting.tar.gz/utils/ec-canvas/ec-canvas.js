import WxCanvas from './wx-canvas';
import * as echarts from './echarts';

let ctx;

function compareVersion(v1, v2) {
  v1 = v1.split('.')
  v2 = v2.split('.')
  const len = Math.max(v1.length, v2.length)

  while (v1.length < len) {
    v1.push('0')
  }
  while (v2.length < len) {
    v2.push('0')
  }

  for (let i = 0; i < len; i++) {
    const num1 = parseInt(v1[i])
    const num2 = parseInt(v2[i])

    if (num1 > num2) {
      return 1
    } else if (num1 < num2) {
      return -1
    }
  }
  return 0
}

Component({
  properties: {
    canvasId: {
      type: String,
      value: 'ec-canvas'
    },

    ec: {
      type: Object
    }
  },

  data: {
    isUseNewCanvas: false
  },

  ready: function () {
    if (!this.data.ec) {
      console.warn('组件需绑定 ec 变量，例：<ec-canvas id="mychart-dom-bar" canvas-id="mychart-bar" ec="{{ ec }}"></ec-canvas>');
      return;
    }

    if (!this.data.ec.lazyLoad) {
      this.init();
    }
  },

  methods: {
    init: function (callback) {
      const version = wx.getSystemInfoSync().SDKVersion

      const canUseNewCanvas = compareVersion(version, '2.9.0') >= 0;
      const isUseNewCanvas = this.data.isUseNewCanvas;

      if (forceUseOldCanvas) {
        // 强制使用旧 canvas, 兼容一些奇怪的情况
        this.initByOldWay(callback);
      } else if (canUseNewCanvas && !isUseNewCanvas) {
        this.setData({ isUseNewCanvas: true });
        this.initByNewWay(callback);
      } else {
        this.initByOldWay(callback);
      }
    },

    initByOldWay(callback) {
      ctx = wx.createCanvasContext(this.data.canvasId, this);
      const canvas = new WxCanvas(ctx, this.data.canvasId, false, this);

      echarts.setCanvasCreator(() => {
        return canvas;
      });

      var query = wx.createSelectorQuery().in(this);
      query.select('.ec-canvas').boundingClientRect(res => {
        if (typeof callback === 'function') {
          this.chart = callback(canvas, res.width, res.height, echarts);
        }
        else if (this.data.ec && typeof this.data.ec.onInit === 'function') {
          this.chart = this.data.ec.onInit(canvas, res.width, res.height, echarts);
        }
        else {
          this.triggerEvent('init', {
            canvas: canvas,
            width: res.width,
            height: res.height,
            echarts: echarts
          });
        }
      }).exec();
    },

    initByNewWay(callback) {
      const query = wx.createSelectorQuery().in(this)
      query
        .select('.ec-canvas')
        .fields({ node: true, size: true })
        .exec(res => {
          const canvasNode = res[0].node
          const dpr = wx.getSystemInfoSync().pixelRatio

          const canvas = new WxCanvas(canvasNode, this.data.canvasId, true, this)
          echarts.setCanvasCreator(() => {
            return canvas
          })

          const width = res[0].width
          const height = res[0].height

          if (typeof callback === 'function') {
            this.chart = callback(canvas, width, height, echarts, dpr)
          } else if (this.data.ec && typeof this.data.ec.onInit === 'function') {
            this.chart = this.data.ec.onInit(canvas, width, height, echarts, dpr)
          } else {
            this.triggerEvent('init', {
              canvas: canvas,
              width: width,
              height: height,
              echarts: echarts,
              dpr: dpr
            })
          }
        })
    },

    canvasToTempFilePath(opt) {
      if (this.data.isUseNewCanvas) {
        // 新版
        const query = wx.createSelectorQuery().in(this);
        query
          .select('.ec-canvas')
          .fields({ node: true, size: true })
          .exec(res => {
            const canvasNode = res[0].node;
            opt.canvas = canvasNode;
            wx.canvasToTempFilePath(opt, this);
          })
      } else {
        // 旧版
        if (!opt.canvasId) {
          opt.canvasId = this.data.canvasId;
        }
        ctx.draw(true, () => {
          wx.canvasToTempFilePath(opt, this);
        });
      }
    },

    touchStart(e) {
      if (this.chart && e.touches.length > 0) {
        var touch = e.touches[0];
        var touchHandler = this.chart.getZr().handler;
        touchHandler.dispatch('mousedown', {
          zrX: touch.x,
          zrY: touch.y
        });
        touchHandler.dispatch('mousemove', {
          zrX: touch.x,
          zrY: touch.y
        });
        touchHandler.processGesture(wrapTouch(e), 'start');
      }
    },

    touchMove(e) {
      if (this.chart && e.touches.length > 0) {
        var touch = e.touches[0];
        var touchHandler = this.chart.getZr().handler;
        touchHandler.dispatch('mousemove', {
          zrX: touch.x,
          zrY: touch.y
        });
        touchHandler.processGesture(wrapTouch(e), 'change');
      }
    },

    touchEnd(e) {
      if (this.chart) {
        var touchHandler = this.chart.getZr().handler;
        touchHandler.dispatch('mouseup', {});
        touchHandler.dispatch('click', {});
        touchHandler.processGesture(wrapTouch(e), 'end');
      }
    }
  }
});

function wrapTouch(event) {
  for (let i = 0; i < event.touches.length; ++i) {
    const touch = event.touches[i];
    touch.offsetX = touch.x;
    touch.offsetY = touch.y;
  }
  return event;
}
