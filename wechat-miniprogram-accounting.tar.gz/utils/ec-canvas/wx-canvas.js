export default class WxCanvas {
  constructor(ctx, canvasId, isNew, canvasNode) {
    this.ctx = ctx;
    this.canvasId = canvasId;
    this.chart = null;
    this.isNew = isNew

    if (isNew) {
      this.canvasNode = canvasNode;
    } else {
      this._initStyle(ctx);
    }

    this._initEvent();
  }

  getContext(contextType) {
    if (contextType === '2d') {
      return this.ctx;
    }
  }

  // 添加事件监听
  _initEvent() {
    const eventNames = [
      {
        wxName: 'touchStart',
        ecName: 'mousedown'
      },
      {
        wxName: 'touchMove',
        ecName: 'mousemove'
      },
      {
        wxName: 'touchEnd',
        ecName: 'mouseup'
      },
      {
        wxName: 'touchEnd',
        ecName: 'click'
      }
    ]

    eventNames.forEach(name => {
      this.ctx[name] && (this.ctx[name] = (e) => {
        const touch = e.touches[0];
        const x = touch.x;
        const y = touch.y;
        
        if (this.chart && !this.chart.isDisposed()) {
          this.chart.getZr().handler.dispatch(name.ecName, {
            zrX: x,
            zrY: y
          });
        }
      });
    });
  }

  _initStyle(ctx) {
    var styles = ['fillStyle', 'strokeStyle', 'globalAlpha',
      'shadowBlur', 'shadowColor', 'shadowOffsetX', 'shadowOffsetY',
      'lineWidth', 'lineCap', 'lineJoin', 'fontSize', 'font',
      'textAlign', 'textBaseline', 'globalCompositeOperation'
    ];

    styles.forEach(style => {
      Object.defineProperty(this, style, {
        get: function () {
          return this.ctx[style];
        },
        set: function (value) {
          this.ctx[style] = value;
        }
      });
    });

    ctx.createRadialGradient = () => {
      return ctx.createCircularGradient(arguments);
    };
  }

  setChart(chart) {
    this.chart = chart;
  }

  addEventListener() {}

  removeEventListener() {}

  createCircularGradient(x0, y0, r0, x1, y1, r1) {
    const canvas = this.isNew ? this.canvasNode : this.canvas;
    const ctx = canvas.getContext('2d');
    const gradient = ctx.createRadialGradient(x0, y0, r0, x1, y1, r1);
    return gradient;
  }

  draw() {
    if (this.isNew) {
      // 新版 Canvas 不需要手动 draw
    } else {
      this.ctx.draw();
    }
  }
}
