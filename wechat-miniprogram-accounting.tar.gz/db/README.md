# 数据库集合说明

## 集合列表

### 1. users（用户表）
存储用户基本信息

**字段说明：**
- `_id`: 用户ID（自动生成）
- `_openid`: 用户OpenID
- `nickName`: 昵称
- `avatarUrl`: 头像URL
- `createTime`: 创建时间
- `updateTime`: 更新时间

### 2. bills（账单表）
存储所有账单记录

**字段说明：**
- `_id`: 账单ID（自动生成）
- `_openid`: 用户OpenID
- `type`: 类型（income/expense）
- `amount`: 金额
- `category`: 分类信息（对象）
  - `name`: 分类名称
  - `icon`: 图标
  - `color`: 颜色
- `account`: 账户信息（对象）
  - `name`: 账户名称
  - `icon`: 图标
- `date`: 日期
- `remark`: 备注
- `createTime`: 创建时间

**索引建议：**
- `_openid`: 用户查询
- `date`: 日期查询
- `type`: 类型查询

### 3. categories（分类表）
存储消费和收入分类

**字段说明：**
- `_id`: 分类ID（自动生成）
- `type`: 类型（income/expense）
- `name`: 分类名称
- `icon`: 图标（emoji）
- `color`: 颜色（hex）
- `sort`: 排序
- `createTime`: 创建时间

### 4. accounts（账户表）
存储账户信息

**字段说明：**
- `_id`: 账户ID（自动生成）
- `_openid`: 用户OpenID
- `name`: 账户名称
- `icon`: 图标（emoji）
- `color`: 颜色（hex）
- `balance`: 余额
- `sort`: 排序
- `createTime`: 创建时间

### 5. budget（预算表）
存储月度预算设置

**字段说明：**
- `_id`: 预算ID（自动生成）
- `_openid`: 用户OpenID
- `year`: 年份
- `month`: 月份
- `amount`: 预算金额
- `createTime`: 创建时间
- `updateTime`: 更新时间

## 初始化数据

首次使用时需要运行 `initDB` 云函数来初始化分类和账户数据。

```javascript
wx.cloud.callFunction({
  name: 'initDB',
  success: res => {
    console.log('初始化成功', res)
  }
})
```

## 数据权限

所有集合都需要设置权限为：
- **读权限**: 仅创建者可读
- **写权限**: 仅创建者可写

## 性能优化建议

1. **索引优化**
   - 为 `bills` 集合创建复合索引：`_openid + date`
   - 为 `bills` 集合创建复合索引：`_openid + type`

2. **数据分页**
   - 账单列表查询建议使用 `skip()` 和 `limit()` 进行分页
   - 单次查询建议不超过 20 条记录

3. **数据清理**
   - 建议定期清理超过一年的账单归档数据
   - 可使用云函数定期执行清理任务

## 数据导出

使用 `exportData` 云函数可以导出所有用户数据：

```javascript
wx.cloud.callFunction({
  name: 'exportData',
  success: res => {
    if (res.result.success) {
      const fileID = res.result.fileID
      // 下载文件
      wx.cloud.downloadFile({
        fileID: fileID,
        success: downloadRes => {
          console.log('导出成功', downloadRes.tempFilePath)
        }
      })
    }
  }
})
```

## 数据统计

使用 `getStats` 云函数可以获取统计数据：

```javascript
wx.cloud.callFunction({
  name: 'getStats',
  data: {
    year: 2024,
    month: 1,
    type: 'month'
  },
  success: res => {
    console.log('统计数据', res.result.data)
  }
})
```
